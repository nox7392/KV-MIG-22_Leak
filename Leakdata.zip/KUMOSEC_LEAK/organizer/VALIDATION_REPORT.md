# KUMOSEC LEAK: VALIDATION & CONSISTENCY AUDIT REPORT

**Audit Date**: 2026-10-02 13:52:05 UTC
**Tool**: `validate_kumosec_leak.py`
**Result**: PASSED (0 ERRORS, 0 WARNINGS)

---

## 1. Identity Consistency Audit
* Total canonical employees evaluated: **30 / 30**
* Arun Krishnan consistency:
  * Canonical Employee ID: `KMS-001` (Verified across 12 files)
  * Current Username: `arun-k` (Verified)
  * Legacy Username: `akr` (Verified in legacy exports and old git commits)
  * Aliases: `akr`, `infra-ak` (Verified in `aliases.csv`)
  * Role: `Senior Infrastructure Engineer` (Consistent across all documents)
  * Status: `Former` (Departure date: 2023-01-19 verified)

## 2. Project & Migration Consistency Audit
* KumoVault project identifier: `KV-22` (Verified across register, members, tickets, assets)
* Migration reference identifier: `KV-MIG-22` (Verified across runbooks, tickets, emails, screenshots)
* Incident reference identifier: `SEC-2022-041` (Verified across timeline, tickets, emails, reviews)
* Compromised legacy host: `kv-prod-legacy` (IP: `10.44.22.17`) (Consistent across 9 artifacts)

## 3. Password & Hash Distribution Audit (Section 25 Criteria)
* Total Accounts in `current_auth_export.csv`: **30**
  * Weak Legacy Hashes (MD5): **5** (KMS-018, KMS-022, KMS-023, KMS-027, KMS-028)
  * Moderate Hashes (SHA-256): **10** (KMS-006, KMS-007, KMS-009, KMS-010, KMS-014, KMS-015, KMS-016, KMS-019, KMS-020, KMS-026)
  * Strong Hashes (bcrypt $2b$12$): **10** (KMS-002, KMS-003, KMS-005, KMS-008, KMS-011, KMS-013, KMS-017, KMS-021, KMS-024, KMS-030)
  * Disabled Accounts: **5** (KMS-001, KMS-004, KMS-012, KMS-025, KMS-029)
* Total historical generations in `password_history.csv`: **72**

## 4. Decoy Analysis Audit
* Total Designated Decoys: **7**
  1. KMS-004: Kaito Sato (QA) - Left before incident
  2. KMS-012: Lucas Martin (DeployKit) - Non-KumoVault project
  3. KMS-013: Hannah Reed (HR) - Administrative decoy
  4. KMS-014: Ethan Cole (Finance) - Accounting decoy
  5. KMS-021: Noor Rahman (Sentinel SOC) - Unrelated false positive investigation
  6. KMS-025: Chloe Bennett (UX Designer) - Non-infrastructure design work
  7. KMS-029: Sofia Alvarez (Compliance) - Routine audit decoy
* All 7 decoys are internally consistent and verifiable.

## 5. Critical Safety Verification
* Real API keys, AWS tokens, GitHub tokens, and private key headers: **0 matches**
* Real public IP address search (outside RFC 1918 10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16): **0 matches**
* Real domains search (outside `.example`, `kumosec.example`, `example.com`): **0 matches**
* Forbidden flag strings (`FLAG{`, `CTF{`, `KUMOSEC{`): **0 matches**
