# KUMOSEC LEAK: GRANULAR ARTIFACT MAP

This document maps every critical clue, identity pivot, project reference, and incident indicator across all files in the dataset.

---

## 1. PRIMARY OSINT PIVOT: Arun Krishnan

```text
External GitHub Repository (KumoVault)
  │
  ├─ Commit Author: "Arun Krishnan <arun.krishnan@kumosec.example>"
  ├─ Contributor Profile: "arun-k"
  └─ Deleted historical markdown comment: "Authored by akr during KV-22 bootstrap"
        ↓
KUMOSEC_LEAK / employees/employee_directory.csv
  │
  └─ Employee ID: KMS-001
     Full Name: Arun Krishnan
     Username: arun-k
     Department: Infrastructure
     Role: Senior Infrastructure Engineer
     Project: KumoVault
     Status: Former (Joined 2019-04-08, Left 2023-01-19)
        ↓
KUMOSEC_LEAK / metadata/aliases.csv
  │
  └─ Employee ID: KMS-001
     Username: arun-k
     Old Username: akr
     Primary Alias: akr
     Secondary Alias: infra-ak
     Source: legacy-auth
        ↓
KUMOSEC_LEAK / authentication/legacy_auth_export.csv
  │
  └─ Username: akr
     Employee ID: KMS-001
     Password Hash: 57d84860df8ec1b0f507b5853b05b871 (MD5 for "Kvault@2020")
     Status: active (in 2020 snapshot)
        ↓
KUMOSEC_LEAK / projects/project_register.csv
  │
  └─ Project ID: KV-22
     Project Name: KumoVault
     Owner: Arun Krishnan
     Technical Lead: Arun Krishnan
     Migration Reference: KV-MIG-22
     Status: Archived
        ↓
KUMOSEC_LEAK / projects/kumovault_members.csv
  │
  └─ Arun Krishnan: "Infrastructure Owner"
        ↓
KUMOSEC_LEAK / projects/kumovault_migration.pdf & projects/KV-MIG-22.txt
  │
  └─ Document Reference: KV-MIG-22
     Technical Owner: A. Krishnan
     Target Host: kv-cloud-v2 (10.20.4.12)
     Decommissioned Host: kv-prod-legacy (10.44.22.17)
     Context: Expedited due to security alert SEC-2022-041
        ↓
KUMOSEC_LEAK / infrastructure/asset_inventory.csv & legacy_hosts.txt
  │
  └─ Hostname: kv-prod-legacy
     IP Address: 10.44.22.17
     Owner: KMS-001 (Arun Krishnan)
     Project: KV-22
     Status: archived
     Location: DC-01 Rack B4
     Notes: Decommissioned per SEC-2022-041 / KV-MIG-22
        ↓
KUMOSEC_LEAK / tickets/support_export.csv
  │
  ├─ KV-1842: Assignee: arun-k. Mentions sync daemon socket starvation on kv-prod-legacy; KV-MIG-22.
  └─ KV-1861: Reported by vshah, escalated to nisha-r. Anomalous socket traffic on kv-prod-legacy; ESCALATED TO SEC-2022-041.
        ↓
KUMOSEC_LEAK / communications/
  │
  ├─ email_004.eml: Nisha Rao alerts Arun Krishnan regarding SEC-2022-041 on kv-prod-legacy.
  ├─ email_005.eml: Arun Krishnan (akr) recommends isolating kv-prod-legacy and accelerating KV-MIG-22.
  ├─ email_007.eml: Arun Krishnan schedules expedited cutover with Maya Chen and Vikram Shah.
  ├─ email_012.eml: Adrian Flores confirms network isolation of 10.44.22.17 on VLAN 44.
  └─ email_017.eml: Arun Krishnan gives final completion sign-off on KV-MIG-22.
        ↓
KUMOSEC_LEAK / incident/
  │
  ├─ incident_timeline.csv: Chronological timeline of SEC-2022-041 from 2022-08-14 to 2022-10-04.
  ├─ incident_contacts.csv: Arun Krishnan designated Infrastructure Lead for SEC-2022-041.
  ├─ security_review.pdf: Author Nisha Rao; describes root cause on legacy host 10.44.22.17.
  ├─ recovery_notes.md: Notes by Arun Krishnan and Nisha Rao detailing containment commands.
  └─ postmortem_redacted.pdf: Executive postmortem detailing affected asset kv-prod-legacy.
        ↓
KUMOSEC_LEAK / screenshots/
  │
  ├─ dashboard.png: Shows user akr logged in; warning banner for KV-MIG-22.
  ├─ migration.png: Shows KV-MIG-22 console: Source 10.44.22.17 -> Target 10.20.4.12; operator akr.
  ├─ ticket.png: Shows ticket KV-1861 escalated to SEC-2022-041.
  └─ infrastructure.png: Shows kv-prod-legacy quarantined under SEC-2022-041.
```

---

## 2. DECOY IDENTITIES AND ELIMINATION PROOF

| Decoy Employee | Role & Project | Apparent Evidence | Proof of Decoy / Non-Involvement |
|---|---|---|---|
| **KMS-004: Kaito Sato** (`kaito-dev` / `ksato`) | QA Engineer, KumoVault | Git commits on test suites; tickets like KV-1762. | Left KumoSec on 2021-11-05, months before the 2022 incident occurred. No infrastructure access. |
| **KMS-012: Lucas Martin** (`lucas-m` / `lmartin`) | Software Engineer, DeployKit | Active git history; DeployKit build runner tickets. | Exclusively worked on DeployKit (DK-14). Disconnected from KumoVault and SEC-2022-041. |
| **KMS-013: Hannah Reed** (`hreed` / `hannahr`) | HR Operations, Internal | Signed welcome and farewell emails; offboarding records. | Non-technical administrative role. Handled standard corporate notices. |
| **KMS-014: Ethan Cole** (`ecole` / `eco`) | Finance Analyst, Internal | Budget spreadsheets (email_013); VPN tickets (KV-1850). | Focused exclusively on cloud billing and software licenses. |
| **KMS-021: Noor Rahman** (`nrahman` / `noor-r`) | SOC Analyst, Sentinel | Triaged security alerts (email_008). | Investigated unrelated false-positive alerts on LogPipe sensor forwarders. |
| **KMS-025: Chloe Bennett** (`chloe-b` / `cbennett`) | UX Designer, KumoVault | UI redesign mockups in Figma (email_011). | Interface design only; no involvement in infrastructure, authentication, or incident. |
| **KMS-029: Sofia Alvarez** (`sofia-a` / `salvarez`) | Compliance Officer, Legal | Privacy review questionnaires (email_006). | Routine regulatory compliance audits. No operational or infrastructure connection. |
