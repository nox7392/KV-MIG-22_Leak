# KUMOSEC LEAK: ORGANIZER SOLUTION & WALKTHROUGH GUIDE

## Challenge Overview
* **Company**: KumoSec Technologies
* **Product**: KumoVault (KV-22)
* **Target Audience**: Advanced Cybersecurity / OSINT CTF Participants
* **Estimated Solve Time**: 3–5 hours
* **Difficulty**: Hard

---

## Intended 13-Step Primary Investigation Path

### Step 1: Initial Pivot from GitHub Repository
* **Action**: Participant starts at the external KumoVault GitHub repository.
* **Finding**: Contributor log displays commits authored by `arun-k` (Arun Krishnan) and historical references to `akr`.

### Step 2: Employee Directory Search
* **File**: `employees/employee_directory.csv`
* **Finding**: Searching for `arun-k` or `Arun Krishnan` reveals:
  * Employee ID: `KMS-001`
  * Role: `Senior Infrastructure Engineer`
  * Department: `Infrastructure`
  * Assigned Project: `KumoVault`
  * Status: `Former` (Left: 2023-01-19)

### Step 3: Identity & Username Correlation
* **File**: `metadata/aliases.csv`
* **Finding**: Entry for `KMS-001` shows:
  * Username: `arun-k`
  * Old Username: `akr`
  * Aliases: `akr`, `infra-ak`
  * Source: `legacy-auth`
* **Deduction**: Arun Krishnan operated as `akr` during legacy operations.

### Step 4: Historical Authentication Inspection
* **File**: `authentication/legacy_auth_export.csv`
* **Finding**: `akr` appears with legacy MD5 hash `57d84860df8ec1b0f507b5853b05b871` ("Kvault@2020").
* **File**: `authentication/disabled_accounts.csv`
* **Finding**: `arun-k` account was disabled following final migration closure and handover.

### Step 5: Project Register & Identifier Discovery
* **File**: `projects/project_register.csv`
* **Finding**: Project KumoVault has:
  * Project ID: `KV-22`
  * Technical Lead & Owner: `Arun Krishnan`
  * Status: `Archived`
  * Migration Reference: `KV-MIG-22`

### Step 6: Team Roster Verification
* **File**: `projects/kumovault_members.csv`
* **Finding**: Confirms Arun Krishnan was the designated "Infrastructure Owner" alongside Maya Chen ("Lead Developer") and Nisha Rao ("Security Reviewer").

### Step 7: Migration Runbook Analysis
* **Files**: `projects/kumovault_migration.pdf`, `projects/legacy_migration.md`, `projects/KV-MIG-22.txt`
* **Finding**:
  * Reference `KV-MIG-22` was authored by `A. Krishnan`.
  * Cutover moved data from legacy host `kv-prod-legacy` (10.44.22.17) to cloud host `kv-cloud-v2` (10.20.4.12).
  * Notes state migration was expedited due to security alert `SEC-2022-041`.

### Step 8: Document Metadata Extraction
* **Tools**: `pdfinfo`, `exiftool`, or `pymupdf` on `kumovault_overview.pdf` and `kumovault_migration.pdf`.
* **Finding**:
  * Author: `A. Krishnan`
  * Creator: `LibreOffice 7.3`
  * Created: `2022-08-14`

### Step 9: Infrastructure Inventory Mapping
* **File**: `infrastructure/asset_inventory.csv`
* **Finding**: Asset `AST-001`:
  * Hostname: `kv-prod-legacy`
  * IP Address: `10.44.22.17`
  * Owner: `KMS-001`
  * Project: `KV-22`
  * Status: `archived`
  * Notes: "Decommissioned per SEC-2022-041 / KV-MIG-22"

### Step 10: Support Ticket Correlation
* **File**: `tickets/support_export.csv`
* **Finding**:
  * `KV-1842`: Daemon sync timeout on `kv-prod-legacy`; assigned to `arun-k`; references `KV-MIG-22`.
  * `KV-1861`: Anomalous socket activity on 10.44.22.17; escalated by `vshah` to `nisha-r`; officially escalated to `SEC-2022-041`.

### Step 11: Email Verification
* **File**: `communications/`
  * `email_004.eml`: Nisha Rao notifies Arun Krishnan of SEC-2022-041 alert on kv-prod-legacy.
  * `email_005.eml`: Arun Krishnan (`akr`) instructs host isolation and KV-MIG-22 cutover.
  * `email_012.eml`: Adrian Flores confirms VLAN 44 quarantine of 10.44.22.17.
  * `email_017.eml`: Arun Krishnan confirms final decommission and migration completion.

### Step 12: Incident & Forensic Timeline Reconstruction
* **Files**: `incident/incident_timeline.csv`, `incident/security_review.pdf`, `incident/postmortem_redacted.pdf`
* **Finding**:
  * Root cause was unpatched sync daemon on 10.44.22.17 utilizing obsolete MD5 authentication.
  * Rapid containment prevented lateral movement.
  * Postmortem signed off by Arun Krishnan and Nisha Rao.

### Step 13: Transition to Next CTF Stage
* **Conclusion**: Participant has reconstructed:
  * **Who**: Arun Krishnan (`arun-k`, `akr`, `KMS-001`)
  * **What**: KumoVault (`KV-22`)
  * **Where**: `kv-prod-legacy` (`10.44.22.17`)
  * **When**: August–October 2022
  * **Which Identifier**: `KV-MIG-22` / `SEC-2022-041`
* The participant can now pivot to external CTF infrastructure / challenge endpoints using these correlated identifiers.

---

## Alternate Investigation Paths

### Alternate Path A: Starting from Tickets
1. Participant filters `support_export.csv` for "Escalated" or "Security".
2. Discovers `KV-1861` referencing `SEC-2022-041` and `kv-prod-legacy` (10.44.22.17).
3. Follows assignee `nisha-r` to `incident/incident_contacts.csv`.
4. Identifies Infrastructure Lead as Arun Krishnan (`KMS-001` / `arun-k`).
5. Reconnects to `KV-MIG-22`.

### Alternate Path B: Starting from Infrastructure
1. Participant reviews `infrastructure/asset_inventory.csv`.
2. Spots `kv-prod-legacy` marked as `archived` with note `SEC-2022-041 / KV-MIG-22`.
3. Checks owner `KMS-001` in `employee_directory.csv` -> Arun Krishnan.
4. Pivots into `metadata/aliases.csv` -> `akr`.

---

## Key Canonical Values Quick Reference Table

| Parameter | Canonical Value |
|---|---|
| Primary Person of Interest | Arun Krishnan |
| Employee ID | KMS-001 |
| Primary Username | arun-k |
| Legacy Username / Aliases | akr / infra-ak |
| Primary Project Name | KumoVault |
| Project Identifier | KV-22 |
| Migration Identifier | KV-MIG-22 |
| Incident Identifier | SEC-2022-041 |
| Affected Legacy Hostname | kv-prod-legacy |
| Affected Legacy IP Address | 10.44.22.17 |
| Target Cloud Hostname / IP | kv-cloud-v2 / 10.20.4.12 |
| Incident Commander | Nisha Rao (nisha-r / KMS-005) |
